package com.example.minor_project1.models;

public enum TransactionStatus {

    COMPLETED,
    FAILED,

    IN_PROCESS

}
