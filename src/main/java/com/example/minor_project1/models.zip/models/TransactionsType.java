package com.example.minor_project1.models;

public enum TransactionsType {

    ISSUE,
    RETURN
}
