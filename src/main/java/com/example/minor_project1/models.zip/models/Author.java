package com.example.minor_project1.models;


import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;

    private String authorName;

    @Column(unique = true, nullable = false)
    private String email;

    @CreationTimestamp
    private Date CreatedOn;

    @OneToMany(mappedBy = "authorId")
    private List<Book> bookList;

}

// ABC  email@gmail.com 50
// ABC  email@gmail.com 51