package com.example.minor_project1.models;

public enum Genre {
    PROGRAMMING, //0
    FRICTION, //1
    NON_FRICTION,
    STORY,
    SCIENCE,
    HUMAN_RESOURCES

}
